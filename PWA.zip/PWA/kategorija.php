<?php
include 'db.php';

$kategorija = isset($_GET['kategorija']) ? $conn->real_escape_string($_GET['kategorija']) : '';

?>
<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>Kategorija: <?php echo htmlspecialchars($kategorija); ?> - News Portal</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>News Portal</h1>
  <nav>
    <a href="index.php">Početna</a>
    <a href="form.html">Dodaj članak</a>
    <a href="kategorija.php?kategorija=Sport">Sport</a>
    <a href="kategorija.php?kategorija=Kultura">Kultura</a>
    <a href="administrator.php">Administracija</a>
    <a href="logout.php">Odjavi se</a>
  </nav>
</header>
<h2 class="vijesti">Vijesti iz kategorije: <?php echo htmlspecialchars($kategorija); ?></h2>
<main class="grid">
<?php
if ($kategorija) {
    $query = "SELECT id, naslov, opis, slika, datum FROM clanak WHERE kategorija = '$kategorija' AND arhiva = 0 ORDER BY datum DESC";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        echo "<div class='grid-vijesti'>";
        while ($row = $result->fetch_assoc()) {
            echo "<article class='vijest'>";
            echo "<a href='clanak.php?id={$row['id']}'><img src='{$row['slika']}' alt='Slika'></a>";
            echo "<h3><a href='clanak.php?id={$row['id']}'>{$row['naslov']}</a></h3>";
            echo "<p>{$row['opis']}</p>";
            echo "<p class='datum'>" . date("d.m.Y", strtotime($row['datum'])) . "</p>";
            echo "</article>";
        }
        echo "</div>";
    } else {
        echo "<p>Nema članaka u odabranoj kategoriji.</p>";
    }
} else {
    echo "<p>Kategorija nije definirana.</p>";
}
?>
</main>

<footer>
  <p>&copy; 2025 News Portal</p>
</footer>
</body>
</html>
