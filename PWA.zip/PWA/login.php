<?php
include 'db.php';
session_start();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $korisnicko_ime = $_POST['korisnicko_ime'];
    $lozinka = $_POST['lozinka'];

    $stmt = $conn->prepare("SELECT * FROM korisnik WHERE korisnicko_ime = ?");
    $stmt->bind_param("s", $korisnicko_ime);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $korisnik = $result->fetch_assoc();
        if (password_verify($lozinka, $korisnik['lozinka'])) {
            $_SESSION['korisnicko_ime'] = $korisnik['korisnicko_ime'];
            $_SESSION['ime'] = $korisnik['ime'];
            $_SESSION['razina'] = $korisnik['razina'];

            if ($korisnik['razina'] == 1) {
                header("Location: index.php");
                exit();
            } else {
                header("Location: index.php");
                exit();
            }
        } else {
            $msg = "Pogrešna lozinka.";
        }
    } else {
        $msg = "Korisnik ne postoji. <a href='registracija.php'>Registrirajte se</a>";
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Prijava</title>
</head>
<body>
    <h2>Prijava korisnika</h2>
    <form method="post">
        <label>Korisničko ime:</label><br>
        <input type="text" name="korisnicko_ime" required><br><br>

        <label>Lozinka:</label><br>
        <input type="password" name="lozinka" required><br><br>

        <input type="submit" value="Prijavi se">
    </form>
    <p style="color:red;"><?php echo $msg; ?></p>
</body>
</html>
