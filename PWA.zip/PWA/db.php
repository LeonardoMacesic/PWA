<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "newsportal";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Greška u povezivanju: " . $conn->connect_error);
}
?>
