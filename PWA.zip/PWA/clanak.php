<?php
include 'db.php';
$id = (int) $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM clanak WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>Članak</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>Članak</h1>
  <nav>
    <a href="index.php">Početna</a>
    <a href="form.html">Dodaj članak</a>
    <a href="logout.php">Odjavi se</a>
  </nav>
</header>
<main class= "content">
<?php
if ($row = $result->fetch_assoc()) {
    echo "<article1>";
    echo "<h2>{$row['naslov']}</h2>";
    echo "<img src='{$row['slika']}' width='600'>";
    echo "<p><i>{$row['datum']}</i></p>";
    echo "<p>{$row['tekst']}</p>";
    echo "</article1>";
} else {
    echo "<p>Članak nije pronađen.</p>";
}
?>
</main>
</body>
</html>
