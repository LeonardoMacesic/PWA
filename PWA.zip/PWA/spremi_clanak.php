<?php
include 'db.php';

$naslov = htmlspecialchars($_POST['naslov']);
$opis = htmlspecialchars($_POST['opis']);
$tekst = htmlspecialchars($_POST['tekst']);
$kategorija = htmlspecialchars($_POST['kategorija']);

$dozvoljeni_tipovi = ['image/jpeg', 'image/png', 'image/gif'];
if (!in_array($_FILES['slika']['type'], $dozvoljeni_tipovi)) {
    die("Nepodržani tip slike.");
}

$slika = "slike/" . basename($_FILES['slika']['name']);
move_uploaded_file($_FILES['slika']['tmp_name'], $slika);

$stmt = $conn->prepare("INSERT INTO clanak (naslov, opis, tekst, kategorija, slika) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssss", $naslov, $opis, $tekst, $kategorija, $slika);
$stmt->execute();

echo "<p>Članak je uspješno spremljen.</p>";
echo "<a href='index.php'>Natrag na početnu</a>";
?>
