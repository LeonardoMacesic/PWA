<?php
include 'db.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ime = trim($_POST['ime']);
    $prezime = trim($_POST['prezime']);
    $korisnicko_ime = trim($_POST['korisnicko_ime']);
    $lozinka = $_POST['lozinka'];
    $lozinka2 = $_POST['lozinka2'];

    if ($lozinka !== $lozinka2) {
        $msg = "Lozinke se ne podudaraju!";
    } else {
        $hash_lozinka = password_hash($lozinka, PASSWORD_DEFAULT);
        $level = 0;

        $stmt = $conn->prepare("INSERT INTO korisnik (ime, prezime, korisnicko_ime, lozinka, razina) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $ime, $prezime, $korisnicko_ime, $hash_lozinka, $level);

        if ($stmt->execute()) {
            $msg = "Registracija uspješna! <a href='login.php'>Prijavite se</a>";
        } else {
            $msg = "Greška: Korisničko ime već postoji.";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="hr">
<head>
    <meta charset="UTF-8">
    <title>Registracija korisnika</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Registracija</h2>
    <form method="post">
        <label>Ime:</label><br>
        <input type="text" name="ime" required><br><br>

        <label>Prezime:</label><br>
        <input type="text" name="prezime" required><br><br>

        <label>Korisničko ime:</label><br>
        <input type="text" name="korisnicko_ime" required><br><br>

        <label>Lozinka:</label><br>
        <input type="password" name="lozinka" required><br><br>

        <label>Ponovi lozinku:</label><br>
        <input type="password" name="lozinka2" required><br><br>

        <input type="submit" value="Registriraj se">
    </form>

    <p style="color: red;"><?php echo $msg; ?></p>
</body>
</html>
