<?php
include 'db.php';
session_start();

if (!isset($_SESSION['korisnicko_ime'])) {
    die("Morate se <a href='login.php'>prijaviti</a>.");
}

if ($_SESSION['razina'] != 1) {
    echo "<p>Bok, " . htmlspecialchars($_SESSION['ime']) . "! Nemate prava za pristup ovoj stranici.</p>";
    exit();
}

?>

<?php
include 'db.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM clanak WHERE id = $id");
    header("Location: administrator.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $naslov = $conn->real_escape_string($_POST['naslov']);
    $opis = $conn->real_escape_string($_POST['opis']);
    $tekst = $conn->real_escape_string($_POST['tekst']);
    $kategorija = $conn->real_escape_string($_POST['kategorija']);
    $arhiva = isset($_POST['arhiva']) ? 1 : 0;

    $conn->query("UPDATE clanak SET naslov='$naslov', opis='$opis', tekst='$tekst', kategorija='$kategorija', arhiva=$arhiva WHERE id=$id");
}

$result = $conn->query("SELECT * FROM clanak ORDER BY datum DESC");
?>
<!DOCTYPE html>
<html lang="hr">
<head>
  <meta charset="UTF-8">
  <title>Administracija - News Portal</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header>
  <h1>Administracija</h1>
  <nav>
    <a href="index.php">Početna</a>
    <a href="form.html">Dodaj članak</a>
    <a href="kategorija.php?kategorija=Sport">Sport</a>
    <a href="kategorija.php?kategorija=Kultura">Kultura</a>
  </nav>
</header>

<main>
<?php
while ($row = $result->fetch_assoc()) {
    echo '<form method="POST" style="border:1px solid #ccc; margin-bottom:10px; padding:10px;">';
    echo '<input type="hidden" name="id" value="' . $row['id'] . '">';
    echo '<label>Naslov: <input type="text" name="naslov" value="' . htmlspecialchars($row['naslov']) . '"></label><br>';
    echo '<label>Opis: <textarea name="opis">' . htmlspecialchars($row['opis']) . '</textarea></label><br>';
    echo '<label>Tekst: <textarea name="tekst">' . htmlspecialchars($row['tekst']) . '</textarea></label><br>';
    echo '<label>Kategorija: <input type="text" name="kategorija" value="' . htmlspecialchars($row['kategorija']) . '"></label><br>';
    echo '<label>Arhiviran: <input type="checkbox" name="arhiva"' . ($row['arhiva'] ? ' checked' : '') . '></label><br>';
    echo '<button type="submit" name="update">Spremi promjene</button> ';
    $confirm = htmlspecialchars("return confirm('Jeste li sigurni?')");
echo "<a href='?delete={$row['id']}' onclick=\"$confirm\">Obriši</a>";
    echo '</form>';
}
?>
</main>

<footer>
  <p>&copy; 2025 News Portal</p>
</footer>
</body>
</html>
